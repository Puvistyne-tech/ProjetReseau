package fr.upem.net.tcp.chatfusion.utils;

public class FileHander {
    public static boolean checkIfUserExist(String username){
        //TODO
        return false;
    }
}
