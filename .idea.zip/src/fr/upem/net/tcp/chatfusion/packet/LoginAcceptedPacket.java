package fr.upem.net.tcp.chatfusion.packet;

import java.nio.ByteBuffer;

public class LoginAcceptedPacket implements Packet{
    @Override
    public ByteBuffer toByteBuffer() {
        return null;
    }
}
