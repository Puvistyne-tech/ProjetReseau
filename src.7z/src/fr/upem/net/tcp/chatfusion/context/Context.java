package fr.upem.net.tcp.chatfusion.context;

import java.nio.charset.Charset;

public abstract class Context implements IContext{
//    private final int BUFFER_SIZE;
//    private final Charset CHARSET;

}
