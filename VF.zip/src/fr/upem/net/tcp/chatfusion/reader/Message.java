package fr.upem.net.tcp.chatfusion.reader;

public record Message(String username, String text) {

}
